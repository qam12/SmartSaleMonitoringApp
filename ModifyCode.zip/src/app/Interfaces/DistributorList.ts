export interface DistributorList {
    DistributorRefNo: number;
    DistributorTitle: string;
    DistributorAddress: string;
    DistributorID: number;
    Latitude: number;
    Longitude: number;
}
