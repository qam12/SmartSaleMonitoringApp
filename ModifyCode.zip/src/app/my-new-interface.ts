export interface MyNewInterface {
    Latitude :number;
    Longitude:number;
    ShopID:number;
    DistributorID:number;
    DistributorRefNo:number;
    DistributorTitle:string;
    DistributorAddress:string;

}

// export interface MyNewInterface {
//     userId: number;
//     id:number;
//     title:string;
//     // body:string;


// }